解决Win10作業系統中的Pro/E 、Creo無法使用滑鼠滾輪縮放問題
https://gnustang.blogspot.com/2015/08/win10proe-creo.html

AutoCAD和Creo教程 8.2 三维模型生成三视图
https://www.youtube.com/watch?v=baIisZ44ipM


Creo 5.0 設計入門41 陣列入門操作 2019 09 29 14 37 59
https://www.youtube.com/watch?v=--pigFYGlr8



712 鋼圈內徑
740 最外徑
260 內徑

26.14

712/2=356

356-26=330

330-50=280

662+26+26=714


詠振精密有限公司
https://www.yungchen.tw/tw/
地址： 42157台中市后里區四月路47-2號
04-25580557
機械板金加工件


鉅嘉企業社
鉅嘉金屬有限公司
地址： 421006台中市后里區甲后路二段100巷191號
電話： 04 2558 1113

