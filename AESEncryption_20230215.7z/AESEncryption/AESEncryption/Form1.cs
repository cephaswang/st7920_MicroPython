﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.IO;

// AES Symmetric encryption & decryption in C#
// https://www.youtube.com/watch?v=EgCRyVVCzqI

namespace AESEncryption
{
    public partial class Form1 : Form
    {
        private static byte[] IV = { 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0,0, 0, 0, 0 };
        public Form1()
        {
            InitializeComponent();
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            //String CU = ToMD5(textBox_IV.Text.ToString());
            //MessageBox.Show(CU);
            //this.Close();
        }

        private void buttonEncrypt_Click(object sender, EventArgs e)
        {
            IV = ToMD5(textBox_IV.Text);
            try
            {
                textBoxEncryptedOutput.Text = Encrypt(textBoxInput.Text, textBoxEncryptPassword.Text, IV);
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void buttonDecrypt_Click(object sender, EventArgs e)
        {
            IV = ToMD5(textBox_IV.Text);
            try
            {
                textBoxDecryptOutput.Text = Decrypt(textBoxEncrypted.Text, textBoxDcryptPassword.Text, IV);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void textBoxInput_TextChanged(object sender, EventArgs e)
        {
           // textBoxEncryptPassword.Enabled = textBoxInput.Text.Length > 0;
          //  buttonEncrypt.Enabled = textBoxInput.Text.Length > 0;
        }

        private void textBoxEncryptPassword_TextChanged(object sender, EventArgs e)
        {
          //  textBoxInput.Enabled = textBoxInput.Text.Length > 0;
          //  buttonEncrypt.Enabled = textBoxInput.Text.Length > 0;
        }

        private void textBoxEncrypted_TextChanged(object sender, EventArgs e)
        {
           // textBoxDcryptPassword.Enabled = textBoxInput.Text.Length > 0;
         //   buttonDecrypt.Enabled = textBoxInput.Text.Length > 0;
        }

        private void textBoxDcryptPassword_TextChanged(object sender, EventArgs e)
        {
          //  textBoxEncrypted.Enabled = textBoxInput.Text.Length > 0;
          //  buttonDecrypt.Enabled = textBoxInput.Text.Length > 0;
        }

        private string Encrypt(string plainText, string Password, byte[] IV)
        {
            byte[] Key = ToMD5(Password);

            // Create a new AesManaged.    
            AesManaged aes = new AesManaged();
            aes.Key = Key;
            aes.IV = IV;

            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, aes.CreateEncryptor(), CryptoStreamMode.Write);

            byte[] InputBytes = Encoding.UTF8.GetBytes(plainText);
            cryptoStream.Write(InputBytes, 0, InputBytes.Length);
            cryptoStream.FlushFinalBlock();

            byte[] Encrypted = memoryStream.ToArray();
            String EncS = Convert.ToBase64String(Encrypted);
            byte[] EncB = Encoding.UTF8.GetBytes(EncS);
            // Return encrypted data    
            return Convert.ToBase64String(EncB);
        }

        /*
        public string ToMD5(string str)
        {
            using (var cryptoMD5 = System.Security.Cryptography.MD5.Create())
            {
                //將字串編碼成 UTF8 位元組陣列
                var bytes = Encoding.UTF8.GetBytes(str);

                //取得雜湊值位元組陣列
                var hash = cryptoMD5.ComputeHash(bytes);

                //取得 MD5
                var md5 = BitConverter.ToString(hash)
                  .Replace("-", String.Empty)
                  .ToUpper();

                return md5;
            }
        }
        */

        // https://stackoverflow.com/questions/11454004/calculate-a-md5-hash-from-a-string
        public byte[] ToMD5(string input)
        {
            // Use input string to calculate MD5 hash
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);

                return hashBytes; // .NET 5 +

                // Convert the byte array to hexadecimal string prior to .NET 5
                // StringBuilder sb = new System.Text.StringBuilder();
                // for (int i = 0; i < hashBytes.Length; i++)
                // {
                //     sb.Append(hashBytes[i].ToString("X2"));
                // }
                // return sb.ToString();
            }

        }

        private string Decrypt(string plaintext, string Password, byte[] IV)
        {
            byte[] Key = ToMD5(Password);

            // Create a new AesManaged.    
            AesManaged aes = new AesManaged();
            aes.Key = Key;
            aes.IV = IV;

            MemoryStream memoryStream = new MemoryStream();
            CryptoStream cryptoStream = new CryptoStream(memoryStream, aes.CreateDecryptor(), CryptoStreamMode.Write);

            byte[] InputBytes = Convert.FromBase64String(plaintext);
            string resultText = System.Text.Encoding.UTF8.GetString(InputBytes); // 還原 UTF8 字元
            InputBytes = Convert.FromBase64String(resultText);

            cryptoStream.Write(InputBytes, 0, InputBytes.Length);
            cryptoStream.FlushFinalBlock();

            byte[] Decrypted = memoryStream.ToArray();
            // Return encrypted data    
            return UTF8Encoding.UTF8.GetString(Decrypted, 0, Decrypted.Length);
        }

        private void textBoxEncryptPassword_Leave(object sender, EventArgs e)
        {
            if (((TextBox)sender).Text.Length != 16)
            {
              //  MessageBox.Show("You need to write at least 16 characters.");
            }
        }

        private void textBoxInput_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if(textBoxInput.Text.Length > 0)
            {
              //  byte[] InputBytes = Encoding.UTF8.GetBytes(textBoxInput.Text);
              //  textBoxDebug.Text = BitConverter.ToString(InputBytes).ToLower().Replace("-"," ");
            }
        }

        private void textBoxEncryptPassword_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (textBoxEncryptPassword.Text.Length > 0)
            {
              //  byte[] InputBytes = Encoding.UTF8.GetBytes(textBoxEncryptPassword.Text);
              //  textBoxDebug.Text = BitConverter.ToString(InputBytes).ToLower().Replace("-", " ");
            }
        }

        private void textBoxEncryptedOutput_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (textBoxEncryptedOutput.Text.Length > 0)
            {
               // byte[] InputBytes = Convert.FromBase64String(textBoxEncryptedOutput.Text);
               // textBoxDebug.Text = BitConverter.ToString(InputBytes).ToLower().Replace("-", " ");
            }
        }

        private void textBoxEncrypted_MouseDoubleClick(object sender, MouseEventArgs e)
        {
          //  byte[] InputBytes = Convert.FromBase64String(textBoxEncrypted.Text);
         //   textBoxDebug.Text = BitConverter.ToString(InputBytes).ToLower().Replace("-", " ");
        }

        private void textBoxDcryptPassword_MouseDoubleClick(object sender, MouseEventArgs e)
        {
            if (textBoxDcryptPassword.Text.Length > 0)
            {
               // byte[] InputBytes = Encoding.UTF8.GetBytes(textBoxDcryptPassword.Text);
               // textBoxDebug.Text = BitConverter.ToString(InputBytes).ToLower().Replace("-", "");
            }
        }
    }
}
