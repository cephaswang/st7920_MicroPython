﻿using System;
using System.Linq;
using System.Windows.Forms;
using System.Data.SQLite;
using Claunia.PropertyList;
using System.IO;
using System.Net.Http;
using System.Collections.Generic;
using Newtonsoft.Json;
using System.Web;
using Microsoft.Owin.Hosting;

namespace SQ
{
    public partial class Form1 : Form
    {

        SQLiteConnection SQLite_conn;

        public Form1()
        {
            InitializeComponent();

            try
            {
                SQLite_conn = new SQLiteConnection("Data Source=" + Application.StartupPath + "/assets/CPC_EMS_src.sqlite");
                SQLite_conn.Open();
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                MessageBox.Show("catch" + Convert.ToString(ex.StackTrace));
            }
        }

        private void button_SQLite_Click(object sender, EventArgs e)
        {

            // Anchor Auto size
            // C# windows form for all screen size With resize Controls and Postiioning
            // Fill DataGridView from SQLite DB (C#)
            // https://stackoverflow.com/questions/29107096/fill-datagridview-from-sqlite-db-c

            String BodyText = "";
            SQLiteCommand SQLite_cmd = new SQLiteCommand("SELECT ConFormName FROM CHK_ConCheckForm WHERE ContractCode = 'LAC1060002'", SQLite_conn);
            using (SQLiteDataReader read = SQLite_cmd.ExecuteReader())
            {
                while (read.Read())
                {
                    // https://stackoverflow.com/questions/3370236/changing-the-row-height-of-a-datagridview
                    BodyText = BodyText + read.GetValue(read.GetOrdinal("ConFormName"));
                }
            }
            richTextBox.Text = BodyText;
        }

        private void button_Plist_Click(object sender, EventArgs e)
        {
            NSArray rootDict = null;
            String file = "";
            try
            {
                file = Application.StartupPath + "/assets/Phrase.plist";
                FileInfo file_data = new FileInfo(file);
                rootDict = (NSArray)PropertyListParser.Parse(file_data);
                NSDictionary oneItem = (NSDictionary)rootDict[0];

                String[] names1ST = oneItem.Keys.ToArray();

                richTextBox.Text = names1ST[0];
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.StackTrace);
                MessageBox.Show("catch:" + file + "\n" + Convert.ToString(ex.StackTrace));
                return;
            }
        }

        private void button1_Click(object sender, EventArgs e)
        {//上傳檔案到API
            try
            {
                //string HOST_ADDRESS = "http://210.64.44.194/CPC_EMS_API/";// api/file/upload";
                string HOST_ADDRESS = textBox1.Text.Trim();
                if(HOST_ADDRESS == "")
                {
                    richTextBox.Text += "API網址需設定";
                    return;
                }
                HttpClient s_client;
                //IDisposable s_webApp;

                //s_webApp = WebApp.Start<Startup>(HOST_ADDRESS);
                Console.WriteLine("Web API started!");
                s_client = new HttpClient();
                s_client.BaseAddress = new Uri(HOST_ADDRESS);

                var url = "/CPC_EMS_API/api/file/upload";
                var fileNames = new[] { "CPC_EMS_src.sqlite", "Phrase.plist" };
                using (var content = new MultipartFormDataContent())
                {
                    foreach (var fileName in fileNames)
                    {
                        var fileMimeType = MimeMapping.GetMimeMapping(fileName);
                        var fileBytes = File.ReadAllBytes(fileName);
                        var fileContent = new ByteArrayContent(fileBytes);
                        fileContent.Headers.ContentType = new System.Net.Http.Headers.MediaTypeHeaderValue(fileMimeType);
                        content.Add(fileContent, fileName, fileName);
                    }

                    var response = s_client.PostAsync(url, content).Result;
                    response.EnsureSuccessStatusCode();
                    richTextBox.Text += response.Content.ToString();
                }
                /*把Web API回傳的亂數檔案名稱回傳到Browser*/
            }
            catch(Exception ex) { richTextBox.Text += ex.Message; }
        }

        /*讀取檔案*/
        public byte[] ReadToEnd(Stream stream)
        {
            long originalPosition = stream.Position;
            stream.Position = 0;

            try
            {
                byte[] readBuffer = new byte[4096]; /*最大上傳檔案size*/

                int totalBytesRead = 0;
                int bytesRead;

                while ((bytesRead = stream.Read(readBuffer, totalBytesRead, readBuffer.Length - totalBytesRead)) > 0)
                {
                    totalBytesRead += bytesRead;

                    if (totalBytesRead == readBuffer.Length)
                    {
                        int nextByte = stream.ReadByte();
                        if (nextByte != -1)
                        {
                            byte[] temp = new byte[readBuffer.Length * 2];
                            Buffer.BlockCopy(readBuffer, 0, temp, 0, readBuffer.Length);
                            Buffer.SetByte(temp, totalBytesRead, (byte)nextByte);
                            readBuffer = temp;
                            totalBytesRead++;
                        }
                    }
                }

                byte[] buffer = readBuffer;
                if (readBuffer.Length != totalBytesRead)
                {
                    buffer = new byte[totalBytesRead];
                    Buffer.BlockCopy(readBuffer, 0, buffer, 0, totalBytesRead);
                }
                return buffer;
            }
            finally
            {
                stream.Position = originalPosition;
            }
        }
    }
}
