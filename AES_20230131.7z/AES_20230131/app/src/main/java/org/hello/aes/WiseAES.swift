//
//  WiseAES.swift
//  update0815
//
//  Created by admin on 2022/8/15.
//

/*
 
 let message:String = "{\"MemberLogin\":[{\"ActionType\":\"02\",\"MID\":\"0958990806\",\"MOPassword\":\"e19d5cd5af0378da05f63f891c7467af\",\"MNPassword\":\"d41d8cd98f00b204e9800998ecf8427e\"}]}"

 let AppKey:String = "6D0A1324B695428CB7410C5D4D2AEE3F"
 let AppIV:String  = "93C474F29BDB4E138081DFFE7F524573"
 let encryptedStr:String = WiseAES.enpryptAES(planText: message,AppKey: AppKey,AppIV: AppIV)
 print("encryptedStr: \(encryptedStr)")
 
 let decryptedStr:String = WiseAES.decryptAES(planText: encryptedStr,AppKey: AppKey,AppIV: AppIV)
 print("decryptedStr: \(decryptedStr)")
 
 let MOPassword :String = WiseAES.md5(string: "abcd1234")
 print("MOPassword\(MOPassword)")
 
*/

import Foundation
import CommonCrypto

class WiseAES {

    // 加密
   static func enpryptAES (planText:String, AppKey:String, AppIV:String) -> String {
        if planText.count < 1{
           return ""
        }

        let messageData     = Array(planText.utf8)
        let keyData:[UInt8] = md5ToByte(data_array: Array(AppKey.utf8))
        let ivData:[UInt8]  = md5ToByte(data_array: Array(AppIV.utf8))
       
       print(keyData)
       print(ivData)
       
        let encryptedData:[UInt8] = aesCrypt(data: messageData, keyData:keyData, ivData:ivData, operation:kCCEncrypt)!
        // Byte Array to NSData
        let b64strNSData:NSData = NSData(bytes:encryptedData, length:encryptedData.count)
        // NSData to base64EncodedString
        let b64str:String = b64strNSData.base64EncodedString()
        // print("b64str 49: \(b64str)")
        // String to base64EncodedString
        return Data(b64str.utf8).base64EncodedString()
    }

    // 解密
   static func decryptAES (planText:String, AppKey:String, AppIV:String) -> String {
        if planText.count < 1{
           return ""
        }
       
        let keyData:[UInt8] = md5ToByte(data_array: Array(AppKey.utf8))
        let ivData:[UInt8]  = md5ToByte(data_array: Array(AppIV.utf8))

       // base64 解碼
       // https://stackoverflow.com/questions/31859185/how-to-convert-a-base64string-to-string-in-swift
       // How to convert a base64String to String in Swift?
        var decodedString = ""
        if let decodedData = Data(base64Encoded: planText) {
           decodedString = String(data: decodedData, encoding: .utf8)!
        }

       // Base64String to Data
        if let decodedData1 = Data(base64Encoded: decodedString) {
           // NSData to Byte Array
           let encryptedData = [UInt8](decodedData1)
           let decryptedData:[UInt8] = aesCrypt(data: encryptedData, keyData:keyData, ivData:ivData, operation:kCCDecrypt)!
           // How to convert UInt8 byte array to string in Swift
           // https://stackoverflow.com/questions/29643986/how-to-convert-uint8-byte-array-to-string-in-swift
           if let decryptedString = String(bytes: decryptedData, encoding: .utf8) {
               return decryptedString
           }
        }

        return decodedString
    }
    
    
    
    static func Measurement_GET(UserID:String,UserKind:String,MType:String,QDateTimeS:String,QDateTimeE:String,TopRows:String) -> String{
        let QueryInfo:String =  "{\"QMInfo\":[{\"UserKind\":\"\(UserKind)\",\"UserID\":\"\(UserID)\",\"MType\":\"\(MType)\"," +
                                "\"QDateTimeS\":\"\(QDateTimeS)\",\"QDateTimeE\":\"\(QDateTimeE)\",\"BioClass\":\"\",\"TopRows\":\"\(TopRows)\"}]}"
        
        print(QueryInfo)
        var CheckCode:String = WiseAES.enpryptAES(planText: DateTimeFun.getNow(),
                                                  AppKey: AppConfig.ASKey1,
                                                  AppIV: AppConfig.ASKey2)
        var EquipmentID:String = "D4EEB5CB-CAEA-4A03-948C-8F88F5438EFF"
        EquipmentID = WiseAES.enpryptAES(planText: EquipmentID,
                                        AppKey: AppConfig.ASKey1,
                                        AppIV: AppConfig.ASKey2)
        
        var UploadData:String =  WiseAES.enpryptAES(planText: QueryInfo,
                                                    AppKey: AppConfig.ASKey1,
                                                    AppIV: AppConfig.ASKey2)
        CheckCode   = CheckCode.encodeUrl()!
        EquipmentID = EquipmentID.encodeUrl()!
        UploadData  = UploadData.encodeUrl()!
        let SystemModel:String = AppConfig.SystemModel.encodeUrl()!
        let UData:String =  "CheckCode=\(CheckCode)&EquipmentID=\(EquipmentID)&UploadData=\(UploadData)&SystemModel=\(SystemModel)"
        // print(UData)
        return UData
    }

    // How can I convert a String to an MD5 hash in iOS using Swift?
    // https://stackoverflow.com/questions/32163848/how-can-i-convert-a-string-to-an-md5-hash-in-ios-using-swift
    static func md5(string: String) -> String {
            let length = Int(CC_MD5_DIGEST_LENGTH)
            let messageData = string.data(using:.utf8)!
            var digestData = Data(count: length)

            _ = digestData.withUnsafeMutableBytes { digestBytes -> UInt8 in
                messageData.withUnsafeBytes { messageBytes -> UInt8 in
                    if let messageBytesBaseAddress = messageBytes.baseAddress, let digestBytesBlindMemory = digestBytes.bindMemory(to: UInt8.self).baseAddress {
                        let messageLength = CC_LONG(messageData.count)
                        CC_MD5(messageBytesBaseAddress, messageLength, digestBytesBlindMemory)
                    }
                    return 0
                }
            }
        let outStr :String = digestData.map{ String(format: "%02hhx", $0) }.joined()
        return outStr
    }
    
    
    // MD5 of Data in Swift 3
    // https://stackoverflow.com/questions/39400495/md5-of-data-in-swift-3
    static func md5ToByte (data_array:[UInt8]) ->[UInt8]{
        var digest = [UInt8](repeating: 0, count: Int(CC_MD5_DIGEST_LENGTH))
            CC_MD5(data_array, CC_LONG(data_array.count), &digest)
            var digestHex :[UInt8]?
            digestHex = []
            for index in 0..<Int(CC_MD5_DIGEST_LENGTH) {
                digestHex?.append( digest[index] )
            }
        return digestHex!
    }

    
    // https://stackoverflow.com/questions/37680361/aes-encryption-in-swift
    // operation: kCCEncrypt or kCCDecrypt
    static func aesCrypt(data data_src:[UInt8], keyData:[UInt8], ivData:[UInt8], operation:Int) -> [UInt8]? {
        let cryptLength  = size_t(data_src.count+kCCBlockSizeAES128)
        
        var cryptData :[UInt8]    = [UInt8](repeating: 0, count: cryptLength)

        let keyLength             = size_t(kCCKeySizeAES128)
        let algoritm: CCAlgorithm = UInt32(kCCAlgorithmAES128)
        let options:  CCOptions   = UInt32(kCCOptionPKCS7Padding)

        var numBytesEncrypted :size_t = 0

        let cryptStatus = CCCrypt(CCOperation(operation),
                                  algoritm,
                                  options,
                                  keyData, keyLength,
                                  ivData,
                                  data_src, data_src.count,
                                  &cryptData, cryptLength,
                                  &numBytesEncrypted)
        
        var cryptData_new:[UInt8] = [UInt8](repeating: 0, count: numBytesEncrypted)
        
        if UInt32(cryptStatus) == UInt32(kCCSuccess) {

            if ( cryptData.count > numBytesEncrypted ){
                for Ix in 0 ... numBytesEncrypted - 1 {
                    cryptData_new[Ix] = cryptData[Ix]
                }
                return cryptData_new;
            }
            
            return cryptData;

        } else {
            print("Error: \(cryptStatus)")
        }

        return cryptData;
    }

}

// Swift 使用 AES 方式將資料加解密
// https://franksios.medium.com/ios-%E4%BD%BF%E7%94%A8aes%E6%96%B9%E5%BC%8F%E5%B0%87%E8%B3%87%E6%96%99%E5%8A%A0%E8%A7%A3%E5%AF%86-9fae62a48fc0

// URL decode in iOS
// https://stackoverflow.com/questions/32974795/url-decode-in-ios
extension String
{
    // Any way to replace characters on Swift String?
    // https://stackoverflow.com/questions/24200888/any-way-to-replace-characters-on-swift-string
    func encodeUrl() -> String?
    {
        var strTMP:String = self.addingPercentEncoding( withAllowedCharacters: NSCharacterSet.urlQueryAllowed)!
        strTMP = strTMP.replacingOccurrences(of: "=", with: "%3D", options: .literal, range: nil)
        return strTMP
    }
    func decodeUrl() -> String?
    {
        return self.removingPercentEncoding
    }
}
