package tw.com.ethink.aes01


import android.os.Build
import androidx.annotation.RequiresApi
import java.nio.charset.StandardCharsets
import java.security.InvalidAlgorithmParameterException
import java.security.InvalidKeyException
import java.security.MessageDigest
import java.security.NoSuchAlgorithmException
import java.util.*
import javax.crypto.*
import javax.crypto.spec.IvParameterSpec
import javax.crypto.spec.SecretKeySpec


/*

IOS中的AES加密到JAVA中的解密 (AES Encryption in IOS to Decryption in JAVA)
https://tw.coderbridge.com/questions/0b7b0a76508b4867bce44ae6eb2d0b22

AES — Encryption & Decryption using Kotlin
https://rrohaill.medium.com/aes-encryption-decryption-using-kotlin-7104e79f0f4d

Example for 128bit AES with Java and PHP
https://gist.github.com/thomasdarimont/fae409eaae2abcf83bd6633b961e7f00

*/

class WiseAES {
    // 這裡是宣告加解密的方法
    var algorithm = "AES/CBC/PKCS5Padding"

    fun md5ToByte_sample(): String {
        val AppKey = "6D0A1324B695428CB7410C5D4D2AEE3F"
        // How to convert Strings to and from UTF8 byte arrays in Java
        // https://stackoverflow.com/questions/88838/how-to-convert-strings-to-and-from-utf8-byte-arrays-in-java
        val c3: ByteArray? = md5ToByte(AppKey.toByteArray(StandardCharsets.UTF_8))
        return String(c3!!)
    }

    @RequiresApi(Build.VERSION_CODES.O)
    fun enpryptAES(planText: String, AppKey: String, AppIV: String): String {
        var keyData: ByteArray = md5ToByte(AppKey.toByteArray(StandardCharsets.UTF_8))!!
        var ivData: ByteArray = md5ToByte(AppIV.toByteArray(StandardCharsets.UTF_8))!!

        val decodedString: String? = encrypt(
            algorithm,
            planText,
            SecretKeySpec(keyData, 0, keyData.size, "AES"),
            IvParameterSpec(ivData)
        )

        println(decodedString);
        // base64 編碼
        val encodedString = Base64.getEncoder().encodeToString(decodedString!!.toByteArray())
        return encodedString!!
    }


    @RequiresApi(Build.VERSION_CODES.O)
    fun decryptAES(planText: String, AppKey: String, AppIV: String): String {
        var keyData: ByteArray = md5ToByte(AppKey.toByteArray(StandardCharsets.UTF_8))!!
        var ivData: ByteArray = md5ToByte(AppIV.toByteArray(StandardCharsets.UTF_8))!!

        // base64 解碼
        val decodedBytes: ByteArray = Base64.getDecoder().decode(planText)
        var decodedSrc = String(decodedBytes)

        println(decodedSrc);

        val decodedString: String? = decrypt(
            algorithm,
            decodedSrc,
            SecretKeySpec(keyData, 0, keyData.size, "AES"),
            IvParameterSpec(ivData)
        )
        return decodedString!!
    }

    // https://www.baeldung.com/java-aes-encryption-decryption
    @RequiresApi(Build.VERSION_CODES.O)
    @Throws(
        NoSuchPaddingException::class,
        NoSuchAlgorithmException::class,
        InvalidAlgorithmParameterException::class,
        InvalidKeyException::class,
        BadPaddingException::class,
        IllegalBlockSizeException::class
    )
    fun encrypt(
        algorithm: String?, input: String, key: SecretKey?,
        iv: IvParameterSpec?
    ): String? {
        val cipher = Cipher.getInstance(algorithm)
        cipher.init(Cipher.ENCRYPT_MODE, key, iv)
        val cipherText = cipher.doFinal(input.toByteArray())
        return Base64.getEncoder().encodeToString(cipherText)
    }

    // https://www.baeldung.com/java-aes-encryption-decryption
    @RequiresApi(Build.VERSION_CODES.O)
    @Throws(
        NoSuchPaddingException::class,
        NoSuchAlgorithmException::class,
        InvalidAlgorithmParameterException::class,
        InvalidKeyException::class,
        BadPaddingException::class,
        IllegalBlockSizeException::class
    )
    fun decrypt(
        algorithm: String?, cipherText: String?, key: SecretKey?,
        iv: IvParameterSpec?
    ): String {
        val cipher = Cipher.getInstance(algorithm)
        cipher.init(Cipher.DECRYPT_MODE, key, iv)
        val plainText = cipher.doFinal(
            Base64.getDecoder().decode(cipherText)
        )
        return String(plainText)
    }

    // 在 Android 上使用 kotlin 語言, 實作 AES 加解密 是簡單的
    // https://kotlin.tw/kotlin/aes

    // get MD5 string from byte array - Android java.security
    // http://www.java2s.com/example/android/java.security/get-md5-string-from-byte-array.html
    fun md5ToByte(data_array: ByteArray?): ByteArray {
        if (data_array != null) {
            //  printByteArray(data_array)
        }
        var resultByteArray: ByteArray = ByteArray(0)
        var md5: MessageDigest? = null
        try {
            md5 = MessageDigest.getInstance("MD5")
            md5.update(data_array)
        } catch (e: NoSuchAlgorithmException) {
        }
        if (md5 != null) {
            resultByteArray = md5.digest()
        }
        printByteArray(resultByteArray)
        return resultByteArray
    }

    fun printByteArray(data_array: ByteArray) {
        print("[")
        val LenTh: Int = data_array.size - 1
        for (Ix in 0..LenTh) {
            print(data_array[Ix])
            print(",")
        }
        println("]")
    }
}

