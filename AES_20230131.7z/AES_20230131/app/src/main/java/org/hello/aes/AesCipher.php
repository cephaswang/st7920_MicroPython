<?php

/*
thomasdarimont/AesCipher.php
https://gist.github.com/thomasdarimont/fae409eaae2abcf83bd6633b961e7f00
*/

class AesCipher {
    
    private const OPENSSL_CIPHER_NAME = "aes-128-cbc";
    private const CIPHER_KEY_LEN = 16; //128 bits

    private static function fixKey($key) {
        
        if (strlen($key) < AesCipher::CIPHER_KEY_LEN) {
            //0 pad to len 16
            return str_pad("$key", AesCipher::CIPHER_KEY_LEN, "0"); 
        }
        
        if (strlen($key) > AesCipher::CIPHER_KEY_LEN) {
            //truncate to 16 bytes
            return substr($key, 0, AesCipher::CIPHER_KEY_LEN); 
        }

        return $key;
    }

    /**
    * Encrypt data using AES Cipher (CBC) with 128 bit key
    * 
    * @param type $key - key to use should be 16 bytes long (128 bits)
    * @param type $iv - initialization vector
    * @param type $data - data to encrypt
    * @return encrypted data in base64 encoding with iv attached at end after a :
    */
    static function encrypt($key, $iv, $data) {
        $encodedEncryptedData = base64_encode(openssl_encrypt($data, AesCipher::OPENSSL_CIPHER_NAME, AesCipher::fixKey($key), OPENSSL_RAW_DATA, $iv));
        return base64_encode($encodedEncryptedData);
    }

    /**
    * Decrypt data using AES Cipher (CBC) with 128 bit key
    * 
    * @param type $key - key to use should be 16 bytes long (128 bits)
    * @param type $data - data to be decrypted in base64 encoding with iv attached at the end after a :
    * @return decrypted data
    */
    static function decrypt($key,$iv, $encrypted) {
		$encryptedSrc = base64_decode(base64_decode($encrypted));
        $decryptedData = openssl_decrypt($encryptedSrc, AesCipher::OPENSSL_CIPHER_NAME, AesCipher::fixKey($key), OPENSSL_RAW_DATA, $iv);
        return $decryptedData;
    }
};

$ecrypted = AesCipher::encrypt(md5('6D0A1324B695428CB7410C5D4D2AEE3F',TRUE), md5('93C474F29BDB4E138081DFFE7F524573',TRUE), 'demo');
echo $ecrypted."<br>";

$decrypted = AesCipher::decrypt(md5('6D0A1324B695428CB7410C5D4D2AEE3F',TRUE), md5('93C474F29BDB4E138081DFFE7F524573',TRUE), "UXpRTDgyRDBpd2RoN2FhK1hEMDV4dz09");

echo $decrypted."<br>";

?>