package org.hello.aes;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;

import tw.com.ethink.aes01.WiseAES;

//參考，0907安卓版，AES成功加解密
//https://drive.google.com/file/d/1dSJz2jumrzpeC7Zj7rGW8xquBiAei36u/view?usp=share_link


public class MainActivity extends AppCompatActivity {

    Button Button_ENC, Button_DEC;
    // String UploadData = "{\"MemberLogin\":[{\"ActionType\":\"02\",\"MID\":\"0958990806\",\"MOPassword\":\"e19d5cd5af0378da05f63f891c7467af\",\"MNPassword\":\"d41d8cd98f00b204e9800998ecf8427e\"}]}";
    String UploadData = "demo";
    String ASKey1 = "6D0A1324B695428CB7410C5D4D2AEE3F";
    String ASKey2 = "93C474F29BDB4E138081DFFE7F524573";
    WiseAESJ dts = new WiseAESJ();
    String encStr, decStr;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button_ENC = findViewById(R.id.Button_ENC);
        Button_DEC = findViewById(R.id.Button_DEC);

        Button_ENC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                    encStr = dts.enpryptAES(UploadData, ASKey1, ASKey2);
                    System.out.println(encStr);
                }
            }
        });

        Button_DEC.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                    decStr = dts.decryptAES(encStr, ASKey1, ASKey2);
                    System.out.println(decStr);
                }
            }
        });

    }
}