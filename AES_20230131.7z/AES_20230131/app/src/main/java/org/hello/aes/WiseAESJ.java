package org.hello.aes;

/*

thomasdarimont/AesCipher.php
https://gist.github.com/thomasdarimont/fae409eaae2abcf83bd6633b961e7f00

*/

import java.nio.charset.StandardCharsets;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.Base64;
import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;


public class WiseAESJ {

    public String algorithm = "AES/CBC/PKCS5Padding";

    public static String encrypt(String algorithm, String input, SecretKey key, IvParameterSpec iv) {
        String outPut = "";
        try {
            Cipher cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.ENCRYPT_MODE, key, iv);
            byte[] cipherText = cipher.doFinal(input.getBytes(StandardCharsets.UTF_8));
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                Base64.Encoder B64 = Base64.getEncoder();
                outPut = B64.encodeToString(cipherText);
            }
            System.out.println(outPut);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidAlgorithmParameterException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
            e.printStackTrace();
        }
        return outPut;
    }

    public static String decrypt(String algorithm, String sourceText, SecretKey key, IvParameterSpec iv) {
        byte[] plainByte = null;
        String resultStr = "";
        try {
            Cipher cipher = Cipher.getInstance(algorithm);
            cipher.init(Cipher.DECRYPT_MODE, key, iv);
            if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
                Base64.Decoder B64 = Base64.getDecoder();
                plainByte = B64.decode(sourceText);
            }
            byte[] cipherByte = cipher.doFinal(plainByte);
            resultStr =  new String(cipherByte, StandardCharsets.UTF_8);
            System.out.println(resultStr);
        } catch (NoSuchAlgorithmException | NoSuchPaddingException | InvalidAlgorithmParameterException | InvalidKeyException | IllegalBlockSizeException | BadPaddingException e) {
            e.printStackTrace();
        }
        return resultStr;
    }

    public String enpryptAES(String planText, String AppKey, String AppIV) {
        byte[] keyData = md5ToByte(AppKey.getBytes(StandardCharsets.UTF_8));
        byte[] ivData = md5ToByte(AppIV.getBytes(StandardCharsets.UTF_8));

        String decodedString;
        decodedString = encrypt(WiseAESJ.this.algorithm, planText,
                new SecretKeySpec(keyData, 0, keyData.length, "AES"),
                new IvParameterSpec(ivData)
        );

        System.out.println(decodedString);

        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            Base64.Encoder B64 = Base64.getEncoder();
            decodedString = B64.encodeToString(decodedString.getBytes(StandardCharsets.UTF_8));
        }
        return decodedString;
    }

    public String decryptAES(String planText, String AppKey, String AppIV) {
        byte[] keyData = md5ToByte(AppKey.getBytes(StandardCharsets.UTF_8));
        byte[] ivData = md5ToByte(AppIV.getBytes(StandardCharsets.UTF_8));

        // base64 解碼
        String decodedSrc = "";
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
            Base64.Decoder B64 = Base64.getDecoder();
            byte[] decodedByte = B64.decode(planText);
            decodedSrc =  new String(decodedByte, StandardCharsets.UTF_8);
        }

        System.out.println(decodedSrc);

        String decodedString;
        decodedString = decrypt(WiseAESJ.this.algorithm,
                decodedSrc,
                new SecretKeySpec(keyData, 0, keyData.length, "AES"),
                new IvParameterSpec(ivData)
        );
        return decodedString;
    }

    public static byte[] md5ToByte(byte[] data_array) {
        byte[] resultByteArray = null;
        try {
            MessageDigest md5 = MessageDigest.getInstance("MD5");
            md5.update(data_array);
            resultByteArray = md5.digest();
        } catch (NoSuchAlgorithmException e) {
            e.printStackTrace();
        }
        printByteArray(resultByteArray);
        return resultByteArray;
    }

    public static void printByteArray(byte[] data_array) {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        for (int Ux = 0; Ux < data_array.length; Ux++) {
            sb.append(data_array[Ux]);
            sb.append(",");
        }
        sb.append("]");
        System.out.println(sb.toString());
    }

}