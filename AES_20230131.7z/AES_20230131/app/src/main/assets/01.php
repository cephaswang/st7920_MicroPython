<pre>
<?php

// http://127.0.0.1/aes/01.php
// AES/CBC/PKCS5Padding

$data = "1234";
$ASKey1 = "6D0A1324B695428CB7410C5D4D2AEE3F";
$ASKey2 = "93C474F29BDB4E138081DFFE7F524573";
//print_r(getBytes($ASKey1));

$ASKey1_MD5 = md5ToByte(stringToByteArray($ASKey1));
//print_r($ASKey1_MD5);

$ASKey2_MD5 = md5ToByte(stringToByteArray($ASKey2));
//print_r($ASKey2_MD5);

// https://stackoverflow.com/questions/9462380/equivalent-aes-128-bit-in-php
SecretKeySpec skeySpec = new SecretKeySpec(raw, "AES")

$demo = @openssl_encrypt($data, 'AES-128-ECB', byteArrayToString($ASKey1_MD5),OPENSSL_RAW_DATA,byteArrayToString($ASKey2_MD5));

echo base64_encode($demo);

/*
$demo = @openssl_encrypt($data, 'AES-128-CBC', md5($ASKey1,TRUE),OPENSSL_RAW_DATA,md5($ASKey2,TRUE));
$demoUTF8 = utf8_encode($demo);
echo bin2hex($demoUTF8)."<br>";
$demo = @openssl_encrypt($data, 'AES-128-ECB', md5($ASKey1,TRUE),OPENSSL_RAW_DATA,md5($ASKey2,TRUE));
$demoUTF8 = utf8_encode($demo);
echo base64_encode( bin2hex($demoUTF8) )."<br>";

*/

// Z2JlMjRkMXJOVjRBOXpiM3JPUEhNdz09
// UXpRTDgyRDBpd2RoN2FhK1hEMDV4dz09
// QJf/s6y1VwfV4Ii7ejGZhw==


//		function md5ToByte($src_bytes){
//		}

// PHP MD5 equivalent to Java
// https://stackoverflow.com/questions/20470594/php-md5-equivalent-to-java
function md5ToByte($data) {
    assert(is_array($data));

    $dataString = byteArrayToString($data);

    $hashString = md5($dataString, true);
    assert(strlen($hashString) == 16);

    $hash = stringToByteArray($hashString);

    assert(count($hash) == 16);
    return $hash;
}


function stringToByteArray($s) {
    assert(is_string($s));

    $result = array_fill(0, strlen($s), 0);
    for ($i = 0; $i < strlen($s); $i++) {
        $result[$i] = ord($s[$i]);
    }
    return $result;
}

function byteArrayToString($b) {
    assert(is_array($b));

    $asciiString = '';
    for ($i = 0; $i < count($b); $i++) {
        assert($b[$i] >= 0 && $b[$i] <= 255);
        $asciiString .= chr($b[$i]);
    }

    $utf8String = utf8_encode($asciiString);

    return $utf8String;
}


		/** 

		* 轉換一個String字串為byte陣列 

		* @param $str 需要轉換的字串 

		* @param $bytes 目標byte陣列 

		* @author Zikie 

		*/
		function getBytes($string) { 
			$bytes = array(); 
			for($i = 0; $i < strlen($string); $i++){ 
				 $bytes[] = ord($string[$i]); 
			} 
			return $bytes; 
		} 
